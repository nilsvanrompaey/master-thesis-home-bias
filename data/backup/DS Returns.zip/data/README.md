# Notes

- FedFundRate.xlsx: Value at 01/MM/YYYY corresponds to the average value in that month